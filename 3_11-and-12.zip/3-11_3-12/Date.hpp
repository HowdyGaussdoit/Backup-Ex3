 #include <array>
 #include <iostream>
#include "Date.h"
#include <iomanip>

using namespace std;


    Date() {
    /*date class */
        dateM = 0;
        dateD = 0;
        dateY = 0;

        dateNum++;    
    }

    Date( int month, int day, int year ) {/*Parametrized constructor for Date class*/
        dateM = month;
        dateD = day;
        dateY = year;

        dateNum++; 
    }   
    Date(Date &e){ /*Copy constructor */
        dateM = e.dateM;
        dateD = e.dateD;
        dateY = e.dateY;

        //emp_num++;
    } 

/*Setter functions*/
    void setM(int month) { dateM = month; }
    void setD(int day) { dateD = day; }
    void setY(int year) { dateY = year; }

    /*Getter functions*/
    int getM() { return dateM; }
    int getD() { return dateD; }
    int getY() { return dateY; }

    int calcYear() {  
        if(year == 2023) {
            dateY = year;
            return dateY;
        }
        if(year > 2023) {
            cout << "Current year cant be above: " << year << endl; 
        }else{
        return 0;
        }
    }
    /*function to display the values of all data members of class*/
    void display() {
        cout << calcYear();
        cout << "Month" << "\t" << "Day" << "\t"  << setw(8) << "Year" << endl;    
        cout << dateM << "/" << dateD << "/" << dateY  << "\n" << endl; 
    }
    
    ~Date() { /*Destructor of Date class*/  }
    


/*
// utility function to confirm proper day value based on 
// month and year; handles leap years, too
unsigned int Date::checkDay( int testDay ) const {
   static const array< int, monthsPerYear + 1 > daysPerMonth = 
      { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

   // determine whether testDay is valid for specified month
   if ( testDay > 0 && testDay <= daysPerMonth[ month ] )
      return testDay;

   // February 29 check for leap year 
   if ( month == 2 && testDay == 29 && ( year % 400 == 0 || 
      ( year % 4 == 0 && year % 100 != 0 ) ) )
      return testDay;

   throw invalid_argument( "Invalid day for current month and year" );
} // end function checkDay
*/