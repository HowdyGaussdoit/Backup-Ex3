 //#include <array>
 //#include <iostream>
 //#include <iomanip>
#ifndef DATE_H
#define DATE_H

class Date {
    // utility function to check if year is proper for day and month

        int dateM,dateD,dateY;
        int calcYear();
        int dateNum;



    public:
       
        int month;
        int day;
        int year;

        void setM();
        void setD();
        void setY();

        int getM;
        int getD;
        int getY;


};    
#endif   

/*
// utility function to confirm proper day value based on 
// month and year; handles leap years, too
unsigned int Date::checkDay( int testDay ) const {
   static const array< int, monthsPerYear + 1 > daysPerMonth = 
      { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

   // determine whether testDay is valid for specified month
   if ( testDay > 0 && testDay <= daysPerMonth[ month ] )
      return testDay;

   // February 29 check for leap year 
   if ( month == 2 && testDay == 29 && ( year % 400 == 0 || 
      ( year % 4 == 0 && year % 100 != 0 ) ) )
      return testDay;

   throw invalid_argument( "Invalid day for current month and year" );
} // end function checkDay
*/