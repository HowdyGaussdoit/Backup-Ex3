From CPP 11 For Programmers Deitel
