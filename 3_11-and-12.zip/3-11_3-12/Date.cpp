#include <array>
#include <iomanip>
#include "Date.h"
#include <iostream>


using namespace std;
  // class Date() {
    /*date class */
    //    dateM = 0;
    //    dateD = 0;
    //    dateY = 0;

   //     dateNum++;    
   // }


    class Date( int month, int day, int year ) {/*Parametrized constructor for Date class*/
        dateM = month;
        dateD = day;
        dateY = year;

        dateNum++; 
    }   
    Date(Date &e){ /*Copy constructor */
        dateM = e.dateM;
        dateD = e.dateD;
        dateY = e.dateY;

        //emp_num++;
    } 

    /*Setter functions*/
    void setM(int month) { dateM = month; }
    void setD(int day) { dateD = day; }
    void setY(int year) { dateY = year; }

    /*Getter functions*/
    int getM() { return dateM; }
    int getD() { return dateD; }
    int getY() { return dateY; }

    #include <string>
    int calcYear() {  
        if(year == 2023) {
            dateY = year;
            return dateY;
        }
       using std::cout;
        if(year > 2023) {
            cout << "Current year cant be above: " << year << endl; 
        }else{
        return 0;
        }
    }
    /*function to display the values of all data members of class*/
   
    void display() {
        using std::cout;
        cout << calcYear();
        cout << "Month" << "\t" << "Day" << "\t"  << setw(8) << "Year" << endl;    
        cout << dateM << "/" << dateD << "/" << dateY  << "\n" << endl; 
    }
    
    ~Date() { /*Destructor of Date class*/  }


int dateNum = 0;
int main() 
{

Date date[0], date[1]; /*create an array of 2 objects of class Date*/
date[0] = Date (2, 23, 2023);
date[1] = Date (2, 24,2023);

  for(int i = 0; i < 3; i++){ /*loop to call calcNetPay() and display() functions for each object*/
  //  emp[i].calcRaise(); 
    date[i].display();
    ~Date() { /*Destructor of Date class*/  }
  }
   
  return 0;

}

