#include <iostream>
#include "Invoice.h"
#include <string>


using namespace std;


void displayItem(Invoice Item) {
    cout << "your total invoice is:" << Item.getInvoiceAmount() << endl;
    cout << "your item number:" << Item.getPartNumber() << endl;
    cout << "your item desciption:" <<Item.getDesciption() << endl;
    cout << "your quantity:" <<Item.getQuantity() << endl;
    cout << "your price per item:" <<Item.getPricePerItem() << endl;
}

int main() {
    Invoice Invoice1 {"1","first invoice", 30, 10};
    Invoice invoice2 ("2","second invoice", -40, -4);
    displayItem(Invoice1);

}

 /* 
while(true) {
    cout << "Would you like to input? \n Select number : " << endl;
    cout << "1. number 2. desciption 3. quantity 4. price ";
    char ans;
    cin >> ans;

 //switch statement to validate answer
 //and change accordingly

    string inps;
    double inpd;
        switch (ans) {
            case '1':
            cout << "Enter amount: \n";
            cin >> inps;
            Invoice1.setNumber(inps);
            break;
            
            case '2':
            cout << "Enter amount: \n";
            cin >> inps;
            Invoice1.setDescription(inps);
            break;

            case '3':
            cout << "Enter amount: \n";
            cin >> inpd;
            Invoice1.setQuantity(inpd);
            break;

            case '4':
            cout << "Enter amount: \n";
            cin >> inpd;
            Invoice1.setPrice(inpd);
            break;

        }

    displayItem(Invoice1);

    //loop
        cout << "Are you done? \n";
        char endl;
        cin >> end;
        if (end == 'y') {
            break;
        }
   
   */

   