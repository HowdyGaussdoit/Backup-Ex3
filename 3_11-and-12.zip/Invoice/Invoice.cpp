/*

#include <iostream>
#include "Invoice.h"
#include <string>


using namespace std;

Invoice::Invoice(std::string number, std::string description, int quantity, int price) {
    setPartNumber(number);
    setPartDescription(description);
    setQuantity(quantity);
    setPricePerItem(price);
}

void Invoice::setPartNumber(std::string number) {  //setPartNumber
    setPartNumber = number;
}
std::string::Invoice::getPartNumber() {
    return partNumber;
}

void Invoice::setPartDescription(std::string desc) { //setPartDescription
    setPartDescription = desc;
}
std::string::Invoice::getPartDescription() {
    return partDescription;
}

void Invoice::setQuantity(std::string quant) { //setQuantity
    if(quant >= 0) pricePerItem = price;
    else pricePerItem = 0;
}
int Invoice::getPricePerItem() {
    return pricePerItem;
}

int Invoice::getInvoiceAmount() {
    return quantity * pricePerItem;
}



*/