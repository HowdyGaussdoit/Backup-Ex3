#include <string>

//using namespace std;

class Invoice {
    public:
        Invoice (std::string number, std::string description, int quantity, int price);
          : number{partNumber}, description{itemDescription}, quantity{itemQuantity}, price{pricePerItem} {

        void setNumber(std::string partNumber) {
           number =  partNumber;
        }
        std::string getNumber() const {
            return partNumber;
        }
        void setDescription(std::string itemDesciption) {
            description = itemDescription;
        }
        std::string getDescription() const {
            return itemDescription;
        }
        void setQuantity(int itemQuantity) {
            if(itemQuantity >= 0) {
                quantity = itemQuantity;
            }
        }
        int getQuantity() const {
            return quantity;
        }
        void setPrice(int pricePerItem) {
            if(price >= 0) {
                price = PricePerItem;
            }
        }
        int getPrice() const {
            return pricePerItem;
        }
        int getAmount() {
            int amount;
            amount = quantity * pricePerItem;
            return amount;
        }
    };

    private:
        std::string partNumber, partDescription;
        int quantity, pricePerItem ;
        
};